import os
import logging
from flask import Flask, render_template

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

@app.route('/')
def index():
    """Home page with topic overview"""
    return render_template('index.html')

@app.route('/gene-editing')
def gene_editing():
    """Gene editing topic page"""
    return render_template('gene_editing.html')

@app.route('/cell-biology')
def cell_biology():
    """Cell biology topic page"""
    return render_template('cell_biology.html')

@app.route('/energy')
def energy():
    """Energy topic page"""
    return render_template('energy.html')

@app.route('/games')
def games():
    """Interactive games page"""
    return render_template('games.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
