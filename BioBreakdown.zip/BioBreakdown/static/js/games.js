// Games JavaScript for BiologyLearn App
document.addEventListener('DOMContentLoaded', function() {
    console.log('Games module loaded');

    // Initialize all games
    initializeMemoryGame();
    initializeOrganelleSorting();
    initializeQuizGame();
    initializeFoodChainGame();
});

// Memory Game
function initializeMemoryGame() {
    const memoryGame = document.getElementById('memory-game');
    if (!memoryGame) return;

    let flippedCards = [];
    let matchedPairs = 0;
    let moves = 0;
    let gameStarted = false;

    const cards = memoryGame.querySelectorAll('.memory-card');
    const scoreDisplay = document.getElementById('memory-score');
    const resetButton = document.getElementById('reset-memory');

    // Shuffle cards
    shuffleCards();

    // Add click listeners
    cards.forEach(card => {
        card.addEventListener('click', handleCardClick);
    });

    resetButton.addEventListener('click', resetMemoryGame);

    function shuffleCards() {
        const cardArray = Array.from(cards);
        for (let i = cardArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            memoryGame.appendChild(cardArray[j]);
        }
    }

    function handleCardClick() {
        if (this.classList.contains('flipped') || this.classList.contains('matched')) return;
        if (flippedCards.length >= 2) return;

        if (!gameStarted) {
            gameStarted = true;
            moves = 0;
        }

        this.classList.add('flipped');
        flippedCards.push(this);

        if (flippedCards.length === 2) {
            moves++;
            checkMatch();
        }

        updateScore();
    }

    function checkMatch() {
        const [card1, card2] = flippedCards;
        const pair1 = card1.dataset.pair;
        const pair2 = card2.dataset.pair;

        setTimeout(() => {
            if (pair1 === pair2) {
                // Match found
                card1.classList.add('matched');
                card2.classList.add('matched');
                matchedPairs++;

                if (matchedPairs === 4) {
                    setTimeout(() => {
                        showGameComplete();
                    }, 500);
                }
            } else {
                // No match
                card1.classList.remove('flipped');
                card2.classList.remove('flipped');
            }

            flippedCards = [];
        }, 1000);
    }

    function updateScore() {
        if (scoreDisplay) {
            scoreDisplay.textContent = `Moves: ${moves} | Pairs: ${matchedPairs}/4`;
        }
    }

    function showGameComplete() {
        if (scoreDisplay) {
            scoreDisplay.innerHTML = `
                <div class="feedback-success">
                    <i class="fas fa-trophy me-2"></i>
                    Congratulations! Game completed in ${moves} moves!
                </div>
            `;
        }
    }

    function resetMemoryGame() {
        cards.forEach(card => {
            card.classList.remove('flipped', 'matched');
        });

        flippedCards = [];
        matchedPairs = 0;
        moves = 0;
        gameStarted = false;

        updateScore();
        shuffleCards();

        if (scoreDisplay) {
            scoreDisplay.textContent = 'Click cards to start!';
        }
    }

    // Initialize score display
    updateScore();
}

// Organelle Sorting Game
function initializeOrganelleSorting() {
    const sortingGame = document.querySelector('#organelle-items');
    if (!sortingGame) return;

    const organelleItems = document.querySelectorAll('.organelle-item');
    const dropZones = document.querySelectorAll('.cell-drop-zone');
    const resetButton = document.getElementById('reset-sorting');
    const feedback = document.getElementById('sorting-feedback');

    let draggedElement = null;

    // Add drag listeners to organelles
    organelleItems.forEach(item => {
        item.addEventListener('dragstart', handleSortingDragStart);
        item.addEventListener('dragend', handleSortingDragEnd);
    });

    // Add drop listeners to zones
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', handleSortingDragOver);
        zone.addEventListener('dragenter', handleSortingDragEnter);
        zone.addEventListener('dragleave', handleSortingDragLeave);
        zone.addEventListener('drop', handleSortingDrop);
    });

    resetButton.addEventListener('click', resetSortingGame);

    function handleSortingDragStart(e) {
        this.classList.add('dragging');
        draggedElement = this;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', this.outerHTML);
    }

    function handleSortingDragEnd(e) {
        this.classList.remove('dragging');
    }

    function handleSortingDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    function handleSortingDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }

    function handleSortingDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleSortingDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        if (!draggedElement) return;

        const cellType = this.dataset.cellType;
        const organelleType = draggedElement.dataset.type;

        // Check if organelle belongs in this cell type
        const isCorrect = organelleType === cellType || organelleType === 'both';

        if (isCorrect) {
            // Clone the element and add to drop zone
            const clonedElement = draggedElement.cloneNode(true);
            clonedElement.draggable = false;
            clonedElement.classList.remove('dragging');

            // Clear placeholder text
            if (this.querySelector('p')) {
                this.querySelector('p').style.display = 'none';
            }

            this.appendChild(clonedElement);

            // Remove original element
            draggedElement.remove();

            // Check if game is complete
            checkSortingComplete();

        } else {
            // Wrong placement
            showSortingFeedback(false, 'That organelle doesn\'t belong in this type of cell!');
        }

        draggedElement = null;
    }

    function checkSortingComplete() {
        const remainingItems = document.querySelectorAll('#organelle-items .organelle-item');

        if (remainingItems.length === 0) {
            showSortingFeedback(true, 'Excellent! You\'ve correctly sorted all organelles!');
        }
    }

    function showSortingFeedback(isSuccess, message) {
        if (!feedback) return;

        const feedbackClass = isSuccess ? 'feedback-success' : 'feedback-error';
        const icon = isSuccess ? 'fa-check-circle' : 'fa-times-circle';

        feedback.innerHTML = `<div class="${feedbackClass}"><i class="fas ${icon} me-2"></i>${message}</div>`;
        feedback.classList.add('fade-in');

        setTimeout(() => {
            feedback.innerHTML = '';
        }, 3000);
    }

    function resetSortingGame() {
        // Clear drop zones
        dropZones.forEach(zone => {
            const organelles = zone.querySelectorAll('.organelle-item');
            organelles.forEach(organelle => organelle.remove());

            const placeholder = zone.querySelector('p');
            if (placeholder) {
                placeholder.style.display = 'block';
            }
        });

        // Reset organelle bank
        const organelleBank = document.getElementById('organelle-items');
        organelleBank.innerHTML = `
            <div class="organelle-item" draggable="true" data-type="both">
                <i class="fas fa-atom me-2"></i>Nucleus
            </div>
            <div class="organelle-item" draggable="true" data-type="plant">
                <i class="fas fa-leaf me-2"></i>Chloroplast
            </div>
            <div class="organelle-item" draggable="true" data-type="both">
                <i class="fas fa-industry me-2"></i>Mitochondria
            </div>
            <div class="organelle-item" draggable="true" data-type="plant">
                <i class="fas fa-square me-2"></i>Cell Wall
            </div>
            <div class="organelle-item" draggable="true" data-type="animal">
                <i class="fas fa-circle me-2"></i>Centriole
            </div>
            <div class="organelle-item" draggable="true" data-type="both">
                <i class="fas fa-shipping-fast me-2"></i>Ribosome
            </div>
        `;

        // Re-add event listeners
        const newOrganelles = organelleBank.querySelectorAll('.organelle-item');
        newOrganelles.forEach(item => {
            item.addEventListener('dragstart', handleSortingDragStart);
            item.addEventListener('dragend', handleSortingDragEnd);
        });

        if (feedback) {
            feedback.innerHTML = '';
        }
    }
}

// Quiz Game
function initializeQuizGame() {
    const quizGame = document.getElementById('quiz-game');
    if (!quizGame) return;

    const questions = [
        {
            question: "What does CRISPR stand for?",
            answers: [
                "Cell Repair In Systematic Protein Regions",
                "Clustered Regularly Interspaced Short Palindromic Repeats",
                "Cellular Regulation and Protein Repair",
                "Complex RNA-Initiated Systematic Protein Restructuring"
            ],
            correct: 1
        },
        {
            question: "Which organelle is known as the 'powerhouse of the cell'?",
            answers: [
                "Nucleus",
                "Ribosome",
                "Mitochondria",
                "Endoplasmic Reticulum"
            ],
            correct: 2
        },
        {
            question: "What is the primary product of photosynthesis?",
            answers: [
                "Oxygen",
                "Carbon dioxide",
                "Water",
                "Glucose"
            ],
            correct: 3
        },
        {
            question: "Which process breaks down glucose to release energy?",
            answers: [
                "Photosynthesis",
                "Cellular respiration",
                "Mitosis",
                "Transcription"
            ],
            correct: 1
        },
        {
            question: "What type of cell has a membrane-bound nucleus?",
            answers: [
                "Prokaryotic",
                "Bacterial",
                "Eukaryotic",
                "Viral"
            ],
            correct: 2
        }
    ];

    let currentQuestion = 0;
    let score = 0;
    let gameActive = false;

    const startButton = document.getElementById('start-quiz');
    const nextButton = document.getElementById('next-question');
    const restartButton = document.getElementById('restart-quiz');
    const questionText = document.getElementById('quiz-question-text');
    const answersContainer = document.getElementById('quiz-answers');
    const currentQuestionSpan = document.getElementById('current-question');
    const totalQuestionsSpan = document.getElementById('total-questions');
    const scoreDisplay = document.getElementById('quiz-score-display');
    const finalScore = document.getElementById('final-score');
    const maxScore = document.getElementById('max-score');
    const resultMessage = document.getElementById('result-message');
    const quizContent = document.getElementById('quiz-content');
    const quizResults = document.getElementById('quiz-results');

    // Set total questions
    if (totalQuestionsSpan) {
        totalQuestionsSpan.textContent = questions.length;
    }
    if (maxScore) {
        maxScore.textContent = questions.length;
    }

    startButton.addEventListener('click', startQuiz);
    nextButton.addEventListener('click', nextQuestion);
    restartButton.addEventListener('click', restartQuiz);

    function startQuiz() {
        gameActive = true;
        currentQuestion = 0;
        score = 0;

        startButton.style.display = 'none';
        quizContent.style.display = 'block';

        updateScore();
        showQuestion();
    }

    function showQuestion() {
        const question = questions[currentQuestion];

        if (currentQuestionSpan) {
            currentQuestionSpan.textContent = currentQuestion + 1;
        }

        questionText.textContent = question.question;

        answersContainer.innerHTML = '';
        question.answers.forEach((answer, index) => {
            const button = document.createElement('button');
            button.className = 'btn btn-outline-primary quiz-answer';
            button.textContent = answer;
            button.addEventListener('click', () => selectAnswer(index));
            answersContainer.appendChild(button);
        });
    }

    function selectAnswer(selectedIndex) {
        if (!gameActive) return;

        const question = questions[currentQuestion];
        const answerButtons = answersContainer.querySelectorAll('.quiz-answer');
        const isCorrect = selectedIndex === question.correct;

        // Disable all buttons
        answerButtons.forEach((button, index) => {
            button.disabled = true;
            if (index === question.correct) {
                button.classList.add('btn-success');
                button.classList.remove('btn-outline-primary');
            } else if (index === selectedIndex && !isCorrect) {
                button.classList.add('btn-danger');
                button.classList.remove('btn-outline-primary');
            }
        });

        if (isCorrect) {
            score++;
            updateScore();
        }

        // Show next button or finish quiz
        setTimeout(() => {
            if (currentQuestion < questions.length - 1) {
                nextButton.style.display = 'inline-block';
            } else {
                finishQuiz();
            }
        }, 1500);
    }

    function nextQuestion() {
        currentQuestion++;
        nextButton.style.display = 'none';
        showQuestion();
    }

    function updateScore() {
        if (scoreDisplay) {
            scoreDisplay.textContent = score;
        }
    }

    function finishQuiz() {
        gameActive = false;
        quizContent.style.display = 'none';
        quizResults.style.display = 'block';

        if (finalScore) {
            finalScore.textContent = score;
        }

        // Show result message
        let message = '';
        const percentage = (score / questions.length) * 100;

        if (percentage >= 80) {
            message = '<div class="text-success">🏆 Excellent! You\'re a biology expert!</div>';
        } else if (percentage >= 60) {
            message = '<div class="text-warning">👍 Good job! Keep studying to improve!</div>';
        } else {
            message = '<div class="text-info">📚 Keep learning! Review the topics and try again!</div>';
        }

        if (resultMessage) {
            resultMessage.innerHTML = message;
        }
    }

    function restartQuiz() {
        quizResults.style.display = 'none';
        startButton.style.display = 'inline-block';
        nextButton.style.display = 'none';

        currentQuestion = 0;
        score = 0;
        gameActive = false;

        updateScore();
    }
}

// Food Chain Game
function initializeFoodChainGame() {
    const foodChainGame = document.getElementById('food-chain-game');
    if (!foodChainGame) return;

    const organismItems = foodChainGame.querySelectorAll('.organism-item');
    const dropSlots = foodChainGame.querySelectorAll('.drop-slot');
    const checkButton = document.getElementById('check-food-chain');
    const resetButton = document.getElementById('reset-food-chain');
    const feedback = document.getElementById('food-chain-feedback');

    let draggedOrganism = null;

    // Add drag listeners
    organismItems.forEach(item => {
        item.addEventListener('dragstart', handleFoodChainDragStart);
        item.addEventListener('dragend', handleFoodChainDragEnd);
    });

    // Add drop listeners
    dropSlots.forEach(slot => {
        slot.addEventListener('dragover', handleFoodChainDragOver);
        slot.addEventListener('dragenter', handleFoodChainDragEnter);
        slot.addEventListener('dragleave', handleFoodChainDragLeave);
        slot.addEventListener('drop', handleFoodChainDrop);
    });

    checkButton.addEventListener('click', checkFoodChain);
    resetButton.addEventListener('click', resetFoodChain);

    function handleFoodChainDragStart(e) {
        this.classList.add('dragging');
        draggedOrganism = this;
        e.dataTransfer.effectAllowed = 'move';
    }

    function handleFoodChainDragEnd(e) {
        this.classList.remove('dragging');
    }

    function handleFoodChainDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    function handleFoodChainDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }

    function handleFoodChainDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleFoodChainDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        if (!draggedOrganism) return;

        // Clear existing organism in slot
        const existingOrganism =// Games JavaScript for BiologyLearn App
document.addEventListener('DOMContentLoaded', function() {
    console.log('Games JavaScript Loaded');

    // Initialize all games
    initializeMemoryGame();
    initializeOrganelleSorting();
    initializeBiologyQuiz();
    initializeFoodChainGame();
});

// Memory Game Implementation
function initializeMemoryGame() {
    const memoryCards = document.querySelectorAll('.memory-card');
    const resetButton = document.getElementById('reset-memory');
    const scoreDisplay = document.getElementById('memory-score');

    let flippedCards = [];
    let matchedPairs = 0;
    let moves = 0;
    let gameStarted = false;

    if (memoryCards.length === 0) return;

    // Shuffle cards
    shuffleCards();

    // Add click listeners to cards
    memoryCards.forEach(card => {
        card.addEventListener('click', flipCard);
    });

    // Reset button
    if (resetButton) {
        resetButton.addEventListener('click', resetMemoryGame);
    }

    function flipCard() {
        if (!gameStarted) {
            gameStarted = true;
            startTimer();
        }

        if (this.classList.contains('flipped') || this.classList.contains('matched')) {
            return;
        }

        this.classList.add('flipped');
        flippedCards.push(this);

        if (flippedCards.length === 2) {
            moves++;
            updateScore();
            checkForMatch();
        }
    }

    function checkForMatch() {
        const [card1, card2] = flippedCards;
        const pair1 = card1.dataset.pair;
        const pair2 = card2.dataset.pair;

        setTimeout(() => {
            if (pair1 === pair2) {
                // Match found
                card1.classList.add('matched');
                card2.classList.add('matched');
                matchedPairs++;

                if (matchedPairs === memoryCards.length / 2) {
                    // Game completed
                    setTimeout(() => {
                        showMemoryGameComplete();
                    }, 500);
                }
            } else {
                // No match
                card1.classList.remove('flipped');
                card2.classList.remove('flipped');
            }

            flippedCards = [];
        }, 1000);
    }

    function updateScore() {
        if (scoreDisplay) {
            scoreDisplay.textContent = `Moves: ${moves} | Matches: ${matchedPairs}/4`;
        }
    }

    function shuffleCards() {
        const gameBoard = document.getElementById('memory-game');
        if (!gameBoard) return;

        const cardsArray = Array.from(memoryCards);
        for (let i = cardsArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            gameBoard.appendChild(cardsArray[j]);
        }
    }

    function resetMemoryGame() {
        memoryCards.forEach(card => {
            card.classList.remove('flipped', 'matched');
        });
        flippedCards = [];
        matchedPairs = 0;
        moves = 0;
        gameStarted = false;
        updateScore();
        shuffleCards();
    }

    function showMemoryGameComplete() {
        const message = `Congratulations! You completed the memory game in ${moves} moves!`;
        if (scoreDisplay) {
            scoreDisplay.innerHTML = `<div class="feedback-success">${message}</div>`;
        }
    }

    function startTimer() {
        // Could implement a timer here if needed
        updateScore();
    }
}

// Organelle Sorting Game Implementation
function initializeOrganelleSorting() {
    const organelleItems = document.querySelectorAll('.organelle-item');
    const dropZones = document.querySelectorAll('.cell-drop-zone');
    const resetButton = document.getElementById('reset-sorting');
    const feedback = document.getElementById('sorting-feedback');

    if (organelleItems.length === 0) return;

    // Add drag event listeners
    organelleItems.forEach(item => {
        item.addEventListener('dragstart', handleOrganelleDragStart);
        item.addEventListener('dragend', handleOrganelleDragEnd);
    });

    // Add drop event listeners
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', handleDragOver);
        zone.addEventListener('dragenter', handleDragEnter);
        zone.addEventListener('dragleave', handleDragLeave);
        zone.addEventListener('drop', handleOrganelleDrop);
    });

    // Reset button
    if (resetButton) {
        resetButton.addEventListener('click', resetOrganelleSorting);
    }

    function handleOrganelleDragStart(e) {
        this.classList.add('dragging');
        e.dataTransfer.setData('text/plain', JSON.stringify({
            type: this.dataset.type,
            html: this.outerHTML,
            id: this.dataset.id || Math.random().toString(36).substr(2, 9)
        }));
    }

    function handleOrganelleDragEnd(e) {
        this.classList.remove('dragging');
    }

    function handleDragOver(e) {
        e.preventDefault();
    }

    function handleDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }

    function handleDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleOrganelleDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
        const cellType = this.dataset.cellType;
        const organelleType = data.type;

        // Check if organelle belongs in this cell type
        const canDrop = organelleType === 'both' || organelleType === cellType;

        if (canDrop) {
            // Create new organelle element in drop zone
            const newOrganelle = document.createElement('div');
            newOrganelle.innerHTML = data.html;
            const organelleElement = newOrganelle.firstElementChild;
            organelleElement.classList.add('dropped');
            organelleElement.draggable = true;

            // Add drag listeners to dropped organelle for removal
            organelleElement.addEventListener('dragstart', handleDroppedOrganelleDrag);

            this.appendChild(organelleElement);

            // Remove original from bank
            const originalItem = document.querySelector(`.organelle-item[data-type="${organelleType}"]:not(.dropped)`);
            if (originalItem && !originalItem.classList.contains('dropped')) {
                originalItem.style.display = 'none';
            }

            // Update placeholder text
            const placeholder = this.querySelector('p');
            if (placeholder) {
                placeholder.style.display = 'none';
            }

            showSortingFeedback(true, `Correct! ${organelleElement.textContent.trim()} belongs in ${cellType} cells.`);
            checkSortingComplete();
        } else {
            showSortingFeedback(false, `${data.html.match(/>([^<]+)</)[1]} doesn't belong in ${cellType} cells. Try again!`);
        }
    }

    function handleDroppedOrganelleDrag(e) {
        const organelleText = this.textContent.trim();
        const organelleType = this.dataset.type;

        e.dataTransfer.setData('text/plain', JSON.stringify({
            action: 'remove',
            type: organelleType,
            text: organelleText
        }));
    }

    function showSortingFeedback(isCorrect, message) {
        if (!feedback) return;

        const feedbackClass = isCorrect ? 'feedback-success' : 'feedback-error';
        const icon = isCorrect ? 'fa-check-circle' : 'fa-times-circle';

        feedback.innerHTML = `<div class="${feedbackClass}"><i class="fas ${icon} me-2"></i>${message}</div>`;

        setTimeout(() => {
            feedback.innerHTML = '';
        }, 3000);
    }

    function checkSortingComplete() {
        const hiddenItems = document.querySelectorAll('.organelle-item[style*="display: none"]');
        const totalItems = organelleItems.length;

        if (hiddenItems.length === totalItems) {
            setTimeout(() => {
                showSortingFeedback(true, 'Excellent! You\'ve correctly sorted all organelles!');
            }, 500);
        }
    }

    function resetOrganelleSorting() {
        // Show all organelle items
        organelleItems.forEach(item => {
            item.style.display = 'block';
        });

        // Clear drop zones
        dropZones.forEach(zone => {
            const droppedItems = zone.querySelectorAll('.organelle-item');
            droppedItems.forEach(item => item.remove());

            const placeholder = zone.querySelector('p');
            if (placeholder) {
                placeholder.style.display = 'block';
            }
        });

        // Clear feedback
        if (feedback) {
            feedback.innerHTML = '';
        }
    }
}

// Biology Quiz Game Implementation
function initializeBiologyQuiz() {
    const startButton = document.getElementById('start-quiz');
    const nextButton = document.getElementById('next-question');
    const restartButton = document.getElementById('restart-quiz');
    const quizContent = document.getElementById('quiz-content');
    const quizResults = document.getElementById('quiz-results');
    const currentQuestionSpan = document.getElementById('current-question');
    const totalQuestionsSpan = document.getElementById('total-questions');
    const scoreDisplay = document.getElementById('quiz-score-display');
    const finalScoreSpan = document.getElementById('final-score');
    const maxScoreSpan = document.getElementById('max-score');
    const resultMessage = document.getElementById('result-message');

    let currentQuestionIndex = 0;
    let score = 0;
    let quizActive = false;

    const questions = [
        {
            question: "What is the main function of mitochondria?",
            answers: [
                { text: "Protein synthesis", correct: false },
                { text: "Energy production (ATP)", correct: true },
                { text: "Genetic storage", correct: false },
                { text: "Waste removal", correct: false }
            ]
        },
        {
            question: "Which process converts light energy into chemical energy?",
            answers: [
                { text: "Cellular respiration", correct: false },
                { text: "Photosynthesis", correct: true },
                { text: "Glycolysis", correct: false },
                { text: "Fermentation", correct: false }
            ]
        },
        {
            question: "What does CRISPR-Cas9 primarily do?",
            answers: [
                { text: "Produce proteins", correct: false },
                { text: "Edit genes", correct: true },
                { text: "Generate energy", correct: false },
                { text: "Transport materials", correct: false }
            ]
        },
        {
            question: "Which organelle is found in plant cells but not animal cells?",
            answers: [
                { text: "Nucleus", correct: false },
                { text: "Mitochondria", correct: false },
                { text: "Chloroplast", correct: true },
                { text: "Ribosome", correct: false }
            ]
        },
        {
            question: "What is the energy currency of cells?",
            answers: [
                { text: "DNA", correct: false },
                { text: "RNA", correct: false },
                { text: "ATP", correct: true },
                { text: "Glucose", correct: false }
            ]
        }
    ];

    if (!startButton) return;

    // Update total questions display
    if (totalQuestionsSpan) {
        totalQuestionsSpan.textContent = questions.length;
    }
    if (maxScoreSpan) {
        maxScoreSpan.textContent = questions.length;
    }

    // Event listeners
    startButton.addEventListener('click', startQuiz);
    if (nextButton) {
        nextButton.addEventListener('click', nextQuestion);
    }
    if (restartButton) {
        restartButton.addEventListener('click', restartQuiz);
    }

    function startQuiz() {
        currentQuestionIndex = 0;
        score = 0;
        quizActive = true;

        startButton.style.display = 'none';
        if (quizResults) {
            quizResults.style.display = 'none';
        }

        updateScore();
        showQuestion();
    }

    function showQuestion() {
        const question = questions[currentQuestionIndex];

        if (currentQuestionSpan) {
            currentQuestionSpan.textContent = currentQuestionIndex + 1;
        }

        const questionText = document.getElementById('quiz-question-text');
        const answersContainer = document.getElementById('quiz-answers');

        if (questionText) {
            questionText.textContent = question.question;
        }

        if (answersContainer) {
            answersContainer.innerHTML = '';

            question.answers.forEach((answer, index) => {
                const button = document.createElement('button');
                button.className = 'btn btn-outline-primary quiz-answer';
                button.textContent = answer.text;
                button.dataset.correct = answer.correct;
                button.addEventListener('click', selectAnswer);
                answersContainer.appendChild(button);
            });
        }

        if (nextButton) {
            nextButton.style.display = 'none';
        }
    }

    function selectAnswer(e) {
        if (!quizActive) return;

        const selectedButton = e.target;
        const isCorrect = selectedButton.dataset.correct === 'true';
        const allButtons = document.querySelectorAll('.quiz-answer');

        // Disable all buttons
        allButtons.forEach(button => {
            button.disabled = true;

            if (button.dataset.correct === 'true') {
                button.classList.remove('btn-outline-primary');
                button.classList.add('btn-success');
            } else if (button === selectedButton && !isCorrect) {
                button.classList.remove('btn-outline-primary');
                button.classList.add('btn-danger');
            }
        });

        if (isCorrect) {
            score++;
            updateScore();
        }

        // Show next button or finish quiz
        setTimeout(() => {
            if (currentQuestionIndex < questions.length - 1) {
                if (nextButton) {
                    nextButton.style.display = 'inline-block';
                }
            } else {
                finishQuiz();
            }
        }, 1500);
    }

    function nextQuestion() {
        currentQuestionIndex++;
        showQuestion();
    }

    function updateScore() {
        if (scoreDisplay) {
            scoreDisplay.textContent = score;
        }
    }

    function finishQuiz() {
        quizActive = false;

        if (quizContent) {
            quizContent.style.display = 'none';
        }
        if (quizResults) {
            quizResults.style.display = 'block';
        }

        if (finalScoreSpan) {
            finalScoreSpan.textContent = score;
        }

        // Show result message
        if (resultMessage) {
            let message = '';
            const percentage = (score / questions.length) * 100;

            if (percentage >= 80) {
                message = '🎉 Excellent! You have a great understanding of biology!';
            } else if (percentage >= 60) {
                message = '👍 Good job! You have a solid foundation in biology.';
            } else if (percentage >= 40) {
                message = '📚 Not bad! Consider reviewing the topics to improve your knowledge.';
            } else {
                message = '🔬 Keep studying! Biology concepts take time to master.';
            }

            resultMessage.innerHTML = `<p class="lead">${message}</p><p class="text-muted">You scored ${percentage.toFixed(0)}%</p>`;
        }
    }

    function restartQuiz() {
        if (quizContent) {
            quizContent.style.display = 'block';
        }
        if (quizResults) {
            quizResults.style.display = 'none';
        }

        startButton.style.display = 'inline-block';

        // Reset displays
        if (currentQuestionSpan) {
            currentQuestionSpan.textContent = '1';
        }
        if (scoreDisplay) {
            scoreDisplay.textContent = '0';
        }
    }
}

// Food Chain Game Implementation
function initializeFoodChainGame() {
    const organismItems = document.querySelectorAll('.organism-item');
    const dropSlots = document.querySelectorAll('.drop-slot');
    const checkButton = document.getElementById('check-food-chain');
    const resetButton = document.getElementById('reset-food-chain');
    const feedback = document.getElementById('food-chain-feedback');

    if (organismItems.length === 0) return;

    // Add drag event listeners to organisms
    organismItems.forEach(item => {
        item.addEventListener('dragstart', handleOrganismDragStart);
        item.addEventListener('dragend', handleOrganismDragEnd);
    });

    // Add drop event listeners to slots
    dropSlots.forEach(slot => {
        slot.addEventListener('dragover', handleDragOver);
        slot.addEventListener('dragenter', handleDragEnter);
        slot.addEventListener('dragleave', handleDragLeave);
        slot.addEventListener('drop', handleOrganismDrop);
    });

    // Button event listeners
    if (checkButton) {
        checkButton.addEventListener('click', checkFoodChain);
    }
    if (resetButton) {
        resetButton.addEventListener('click', resetFoodChain);
    }

    function handleOrganismDragStart(e) {
        this.classList.add('dragging');
        e.dataTransfer.setData('text/plain', JSON.stringify({
            level: this.dataset.level,
            html: this.outerHTML
        }));
    }

    function handleOrganismDragEnd(e) {
        this.classList.remove('dragging');
    }

    function handleDragOver(e) {
        e.preventDefault();
    }

    function handleDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }

    function handleDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleOrganismDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        // Don't allow dropping if slot is already filled
        if (this.children.length > 0) {
            return;
        }

        const data = JSON.parse(e.dataTransfer.getData('text/plain'));

        // Create organism element in slot
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = data.html;
        const organismElement = tempDiv.firstElementChild;

        // Make it smaller for the slot
        organismElement.style.fontSize = '0.8rem';
        organismElement.style.padding = '0.5rem';
        organismElement.style.margin = '0';
        organismElement.classList.add('in-slot');

        this.appendChild(organismElement);

        // Hide original organism
        const originalOrganism = document.querySelector(`.organism-item[data-level="${data.level}"]:not(.in-slot)`);
        if (originalOrganism) {
            originalOrganism.style.display = 'none';
        }
    }

    function checkFoodChain() {
        const slots = document.querySelectorAll('.chain-slot');
        let isCorrect = true;
        let correctCount = 0;

        slots.forEach((slot, index) => {
            const expectedPosition = index + 1;
            const dropSlot = slot.querySelector('.drop-slot');
            const organism = dropSlot.querySelector('.organism-item');

            if (organism) {
                const actualLevel = parseInt(organism.dataset.level);
                if (actualLevel === expectedPosition) {
                    correctCount++;
                    slot.classList.add('correct-position');
                } else {
                    isCorrect = false;
                    slot.classList.add('incorrect-position');
                }
            } else {
                isCorrect = false;
            }
        });

        showFoodChainFeedback(isCorrect, correctCount, slots.length);

        // Remove position classes after showing feedback
        setTimeout(() => {
            slots.forEach(slot => {
                slot.classList.remove('correct-position', 'incorrect-position');
            });
        }, 3000);
    }

    function showFoodChainFeedback(isCorrect, correctCount, totalCount) {
        if (!feedback) return;

        let message = '';
        let feedbackClass = '';
        let icon = '';

        if (isCorrect) {
            message = '🎉 Perfect! You\'ve built the food chain correctly! Energy flows from producers to top predators.';
            feedbackClass = 'feedback-success';
            icon = 'fa-check-circle';
        } else {
            message = `You got ${correctCount}/${totalCount} positions correct. Remember: Producers → Primary Consumers → Secondary Consumers → Top Predators`;
            feedbackClass = 'feedback-error';
            icon = 'fa-times-circle';
        }

        feedback.innerHTML = `<div class="${feedbackClass}"><i class="fas ${icon} me-2"></i>${message}</div>`;
    }

    function resetFoodChain() {
        // Clear all drop slots
        dropSlots.forEach(slot => {
            slot.innerHTML = '';
        });

        // Show all organisms
        organismItems.forEach(item => {
            item.style.display = 'block';
            item.classList.remove('in-slot');
        });

        // Clear feedback
        if (feedback) {
            feedback.innerHTML = '';
        }

        // Remove position classes
        const slots = document.querySelectorAll('.chain-slot');
        slots.forEach(slot => {
            slot.classList.remove('correct-position', 'incorrect-position');
        });
    }
}

// Utility functions for games
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Export functions for potential use by other scripts
window.BiologyGames = {
    initializeMemoryGame,
    initializeOrganelleSorting,
    initializeBiologyQuiz,
    initializeFoodChainGame
};

console.log('Biology Games initialized successfully!');
