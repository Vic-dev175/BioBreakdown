// Main JavaScript for BiologyLearn App
document.addEventListener('DOMContentLoaded', function() {
    console.log('BiologyLearn App Loaded');

    // Initialize all interactive elements
    initializeQuizzes();
    initializeMatchingGames();
    initializeProgressTracking();
    initializeAnimations();
});

// Quiz functionality
function initializeQuizzes() {
    // Gene editing quiz
    const geneQuiz = document.getElementById('gene-quiz');
    if (geneQuiz) {
        initializeQuiz(geneQuiz, 'quiz-feedback');
    }

    // Energy quiz
    const energyQuiz = document.getElementById('energy-quiz');
    if (energyQuiz) {
        initializeEnergyQuiz();
    }
}

function initializeQuiz(quizContainer, feedbackId) {
    const options = quizContainer.querySelectorAll('.quiz-option');
    const feedback = document.getElementById(feedbackId);

    options.forEach(option => {
        option.addEventListener('click', function() {
            // Disable all options
            options.forEach(opt => opt.disabled = true);

            // Check answer
            const isCorrect = this.dataset.answer === 'correct';

            // Style the clicked option
            this.classList.add(isCorrect ? 'correct' : 'incorrect');

            // Show correct answer if wrong
            if (!isCorrect) {
                options.forEach(opt => {
                    if (opt.dataset.answer === 'correct') {
                        opt.classList.add('correct');
                    }
                });
            }

            // Show feedback
            showFeedback(feedback, isCorrect);
        });
    });
}

function initializeEnergyQuiz() {
    let currentQuestion = 0;
    const questions = document.querySelectorAll('#energy-quiz .quiz-question');

    // First question
    const firstOptions = questions[0].querySelectorAll('.quiz-option');
    firstOptions.forEach(option => {
        option.addEventListener('click', function() {
            const isCorrect = this.dataset.answer === 'correct';
            const feedback = document.getElementById('energy-quiz-feedback');

            // Disable options and show feedback
            firstOptions.forEach(opt => opt.disabled = true);
            this.classList.add(isCorrect ? 'correct' : 'incorrect');

            if (!isCorrect) {
                firstOptions.forEach(opt => {
                    if (opt.dataset.answer === 'correct') {
                        opt.classList.add('correct');
                    }
                });
            }

            showFeedback(feedback, isCorrect);

            // Show second question after delay
            setTimeout(() => {
                document.getElementById('second-question').style.display = 'block';
                document.getElementById('second-question').scrollIntoView({ behavior: 'smooth' });
            }, 2000);
        });
    });

    // Second question
    const secondQuestion = document.getElementById('second-question');
    if (secondQuestion) {
        const secondOptions = secondQuestion.querySelectorAll('.quiz-option');
        secondOptions.forEach(option => {
            option.addEventListener('click', function() {
                const isCorrect = this.dataset.answer === 'correct';
                const feedback = document.getElementById('second-quiz-feedback');

                secondOptions.forEach(opt => opt.disabled = true);
                this.classList.add(isCorrect ? 'correct' : 'incorrect');

                if (!isCorrect) {
                    secondOptions.forEach(opt => {
                        if (opt.dataset.answer === 'correct') {
                            opt.classList.add('correct');
                        }
                    });
                }

                showFeedback(feedback, isCorrect);
            });
        });
    }
}

function showFeedback(feedbackElement, isCorrect) {
    if (!feedbackElement) return;

    const message = isCorrect ? 
        '<div class="feedback-success"><i class="fas fa-check-circle me-2"></i>Correct! Well done!</div>' :
        '<div class="feedback-error"><i class="fas fa-times-circle me-2"></i>Not quite right. Try reviewing the material!</div>';

    feedbackElement.innerHTML = message;
    feedbackElement.classList.add('fade-in');
}

// Matching game functionality
function initializeMatchingGames() {
    const matchingGame = document.getElementById('organelle-matching');
    if (matchingGame) {
        initializeDragAndDrop(matchingGame);
    }
}

function initializeDragAndDrop(container) {
    const draggableItems = container.querySelectorAll('.draggable-item');
    const dropZones = container.querySelectorAll('.drop-zone');
    const feedback = document.getElementById('matching-feedback');

    // Add drag event listeners
    draggableItems.forEach(item => {
        item.addEventListener('dragstart', handleDragStart);
        item.addEventListener('dragend', handleDragEnd);
    });

    // Add drop event listeners
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', handleDragOver);
        zone.addEventListener('dragenter', handleDragEnter);
        zone.addEventListener('dragleave', handleDragLeave);
        zone.addEventListener('drop', handleDrop);
    });

    function handleDragStart(e) {
        this.classList.add('dragging');
        e.dataTransfer.setData('text/plain', this.dataset.organelle);
        e.dataTransfer.setData('text/html', this.outerHTML);
    }

    function handleDragEnd(e) {
        this.classList.remove('dragging');
    }

    function handleDragOver(e) {
        e.preventDefault();
    }

    function handleDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }

    function handleDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function handleDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        const organelle = e.dataTransfer.getData('text/plain');
        const expectedFunction = this.dataset.function;

        if (organelle === expectedFunction) {
            this.classList.add('correct');
            this.innerHTML = `<i class="fas fa-check text-success me-2"></i>${this.textContent}`;

            // Remove the dragged item
            const draggedItem = container.querySelector(`[data-organelle="${organelle}"]`);
            if (draggedItem) {
                draggedItem.style.display = 'none';
            }

            // Check if all matches are complete
            checkMatchingComplete(container, feedback);
        } else {
            // Wrong match - show feedback
            showMatchingFeedback(feedback, false);
        }
    }
}

function checkMatchingComplete(container, feedback) {
    const correctMatches = container.querySelectorAll('.drop-zone.correct');
    const totalMatches = container.querySelectorAll('.drop-zone').length;

    if (correctMatches.length === totalMatches) {
        showMatchingFeedback(feedback, true, 'Excellent! All organelles matched correctly!');
    }
}

function showMatchingFeedback(feedbackElement, isSuccess, message = null) {
    if (!feedbackElement) return;

    const defaultMessage = isSuccess ? 
        'Great job! You\'ve completed the matching game!' : 
        'That\'s not quite right. Try again!';

    const feedbackMessage = message || defaultMessage;
    const feedbackClass = isSuccess ? 'feedback-success' : 'feedback-error';
    const icon = isSuccess ? 'fa-check-circle' : 'fa-times-circle';

    feedbackElement.innerHTML = `<div class="${feedbackClass}"><i class="fas ${icon} me-2"></i>${feedbackMessage}</div>`;
    feedbackElement.classList.add('fade-in');
}

// Progress tracking
function initializeProgressTracking() {
    // Track page visits
    const currentPage = window.location.pathname;
    let visitedPages = JSON.parse(localStorage.getItem('visitedPages') || '[]');

    if (!visitedPages.includes(currentPage)) {
        visitedPages.push(currentPage);
        localStorage.setItem('visitedPages', JSON.stringify(visitedPages));
    }

    // Track quiz completions
    const quizzes = document.querySelectorAll('.quiz-container');
    quizzes.forEach(quiz => {
        const options = quiz.querySelectorAll('.quiz-option');
        options.forEach(option => {
            option.addEventListener('click', function() {
                if (this.dataset.answer === 'correct') {
                    let completedQuizzes = JSON.parse(localStorage.getItem('completedQuizzes') || '[]');
                    const quizId = quiz.id || 'unnamed-quiz';

                    if (!completedQuizzes.includes(quizId)) {
                        completedQuizzes.push(quizId);
                        localStorage.setItem('completedQuizzes', JSON.stringify(completedQuizzes));
                    }
                }
            });
        });
    });
}

// Animation utilities
function initializeAnimations() {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.content-card, .topic-card, .application-card');
    animatedElements.forEach(el => observer.observe(el));

    // Add hover effects to interactive elements
    addHoverEffects();
}

function addHoverEffects() {
    // Add pulse effect to important buttons
    const importantButtons = document.querySelectorAll('.btn-success, .btn-warning, .btn-info');
    importantButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.classList.add('pulse');
        });

        button.addEventListener('mouseleave', function() {
            this.classList.remove('pulse');
        });
    });

    // Add floating effect to icons
    const icons = document.querySelectorAll('.topic-icon i, .feature-icon i');
    icons.forEach(icon => {
        icon.addEventListener('mouseenter', function() {
            this.style.animation = 'float 1s ease-in-out infinite';
        });

        icon.addEventListener('mouseleave', function() {
            this.style.animation = '';
        });
    });
}

// Utility functions
function showLoader(element) {
    element.classList.add('loading');
}

function hideLoader(element) {
    element.classList.remove('loading');
}

function scrollToElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Accessibility improvements
document.addEventListener('keydown', function(e) {
    // Navigate quiz options with arrow keys
    if (e.target.classList.contains('quiz-option')) {
        const options = Array.from(e.target.parentElement.querySelectorAll('.quiz-option'));
        const currentIndex = options.indexOf(e.target);

        if (e.key === 'ArrowDown' && currentIndex < options.length - 1) {
            e.preventDefault();
            options[currentIndex + 1].focus();
        } else if (e.key === 'ArrowUp' && currentIndex > 0) {
            e.preventDefault();
            options[currentIndex - 1].focus();
        } else if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            e.target.click();
        }
    }
});

// Error handling
window.addEventListener('error', function(e) {
    console.error('BiologyLearn Error:', e.error);
    // Could implement user-friendly error reporting here
});

// Export functions for use in other files
window.BiologyLearn = {
    showFeedback,
    showLoader,
    hideLoader,
    scrollToElement,
    initializeDragAndDrop
};
